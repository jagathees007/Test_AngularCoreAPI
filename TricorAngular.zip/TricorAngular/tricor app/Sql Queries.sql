create database TricorDB
use TricorDB
Create table Employee(
ID int not null primary key identity(1,1),
FirstName nvarchar(50),
LastName nvarchar(50),
Gender nvarchar(10),
Age int,
JoinedDate datetime
)

Create procedure [dbo].[AddNewEmpDetails]  
(  
   @FirstName varchar (50),  
   @LastName varchar (50),  
   @Gender varchar (50)  ,
   @Age int,
   @JoinedDate datetime
)  
as  
begin  
   Insert into Employee values(@FirstName,@LastName,@Gender,@Age, @JoinedDate)  
End  


Create procedure [dbo].[UpdateEmpDetails]  
(  
   @ID int,  
   @FirstName varchar (50),  
   @LastName varchar (50),  
   @Gender nvarchar(10),
   @Age int,
   @JoinedDate Datetime  
)  
as  
begin  
   Update Employee  
   set FirstName=@FirstName,  
   LastName=@LastName,  
   Gender=@Gender,
   Age = @Age,
   JoinedDate = @JoinedDate
   where ID=@ID  
End  

Create procedure [dbo].[DeleteEmpById]  
(  
   @ID int  
)  
as  
begin  
   Delete from Employee where ID=@ID  
End  
