﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using CoreAPIAngularCRUD.Models;
using Dapper;
using System.Data;
using Microsoft.AspNetCore.Cors;

namespace CoreAPIAngularCRUD.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private SqlConnection _connection = null;
        private readonly string connStr = "Server=LENOVO\\SQLEXPRESS;Database=TricorDB;Integrated Security = true;";
        public EmployeeController()
        {
           
        }
        [HttpGet("All")]
        
        public IEnumerable<Employee> GetEmployees()
        {
            _connection = new SqlConnection(connStr);
            _connection.Open();
            IEnumerable<Employee> empList = null;
            var sqlQuery = @"Select * from [dbo].Employee";
            empList = _connection.Query<Employee>(sqlQuery).ToList();
            _connection.Close();
            return empList;
        }
        [HttpPost("Search")]
        public Employee SearchEmployee([FromBody]int ID)
        {
            _connection = new SqlConnection(connStr);
            _connection.Open();
            Employee emp = new Employee();
            var sqlQuery = @"Select * from [dbo].Employee where ID =" + ID;
            emp = _connection.QuerySingle<Employee>(sqlQuery);
            _connection.Close();
            return emp;
        }

        [HttpPost("Add")]
        public bool AddEmployee([FromBody]Employee employee)
        {
            _connection = new SqlConnection(connStr);
            _connection.Open();
            var p = new DynamicParameters();
            p.Add("@FirstName", employee.FirstName);
            p.Add("@LastName", employee.LastName);
            p.Add("@Age", employee.Age);
            p.Add("@Gender", employee.Gender);
            p.Add("@JoinedDate", employee.JoinedDate);
            var id = _connection.Execute("AddNewEmpDetails", p, commandType: CommandType.StoredProcedure);
            _connection.Close();
            if (id > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        [HttpPut("Update")]
        public bool UpdateEmployee([FromBody]Employee employee)
        {
            try
            {
                _connection = new SqlConnection(connStr);
                _connection.Open();

                var p = new DynamicParameters();
                p.Add("@FirstName", employee.FirstName);
                p.Add("@LastName", employee.LastName);
                p.Add("@Age", employee.Age);
                p.Add("@Gender", employee.Gender);
                p.Add("@JoinedDate", employee.JoinedDate);
                p.Add("@ID", employee.ID);
                _connection.Execute("UpdateEmpDetails", p, commandType: CommandType.StoredProcedure);
                _connection.Close();
                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }
        [HttpPost("Delete")]
        public bool DeleteEmployee([FromBody]int ID)
        {
            try
            {
                _connection = new SqlConnection(connStr);
                _connection.Open();
                var p = new DynamicParameters();
                p.Add("@ID", ID);

                _connection.Execute("DeleteEmpById", p, commandType: CommandType.StoredProcedure);
                _connection.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}