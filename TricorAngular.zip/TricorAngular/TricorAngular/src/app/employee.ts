export class Employee {
    id:number;
    firstName: string;
    lastName: string;
    age: number;
    gender: string;
    joinedDate: Date;
}
