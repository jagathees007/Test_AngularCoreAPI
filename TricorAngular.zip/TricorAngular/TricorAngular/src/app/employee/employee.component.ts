import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import {Employee } from '../employee';
import { FormGroup, FormControl, FormBuilder} from '@angular/forms';
import {DatePipe} from '@angular/common';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers:[DatePipe]
})
export class EmployeeComponent implements OnInit {

  
  private readonly globalUrl: string = "http://localhost:5000/";
  private employees :  any;
  private emp : Employee;
  private employeeForm: FormGroup;
  dtOptions: DataTables.Settings = {};
  

  constructor(private _http : HttpClient, private formBuilder: FormBuilder, private datePipe: DatePipe) { 
    this.employeeForm = this.formBuilder.group({
      ID : [],
      FirstName: [],
      LastName: [],
      Age: [],
      Gender:[],
      JoinedDate: []
    })
  }

  ngOnInit() {
       this.loadAllEmployees();
       this.dtOptions = {
        pagingType: 'full_numbers'
      };
  }


  loadAllEmployees(): any{
    
    this._http.get(this.globalUrl+"api/Employee/All").subscribe( x=> { console.log(x); this.employees = x; });
  }
  onSubmitEmployee()  {
    if(this.employeeForm.value.ID == null){
     console.log(this.employeeForm.value)
      this._http.post(this.globalUrl+"api/Employee/Add",this.employeeForm.value).subscribe(x=> {
        if(x == true){
          alert("Employee Inserted Successfully!");
        }
        else{
          alert("Error!");
        }
      });
      
    }
    else  {
      this._http.put(this.globalUrl+"api/Employee/Update",this.employeeForm.value).subscribe(x=> {
    if(x== true){
      alert("Employee Updated Successfully!");
        }
        else{
          alert("Error!");
        }
      });
      
    }
    this.loadAllEmployees();
    this.employeeForm.reset();
  }

  GetDetail(ID : number): any{
    debugger
    this._http.post<Employee>(this.globalUrl+ "api/Employee/Search",ID).subscribe(x=> {
      
      alert(JSON.stringify(x));
    })
  }
  EditEmployee(ID : number): any{
    this._http.post(this.globalUrl+ "api/Employee/Search", ID).subscribe(x=>{
      this.emp = x as Employee;
      console.log(this.emp);
      this.employeeForm.setValue({
        ID : this.emp.id,
        FirstName: this.emp.firstName,
        LastName: this.emp.lastName,
        Age: this.emp.age,
        Gender: this.emp.gender,
        JoinedDate: this.datePipe.transform(this.emp.joinedDate, "yyyy-MM-dd")
      })

    })
  }

  DeleteEmployee(ID : number): any{
    if(confirm("Are you sure want to delete this record?")){
     
  
this._http.post(this.globalUrl+ "api/Employee/Delete", ID).subscribe(x=>{
  alert("User Deleted Successfully!");
  this.loadAllEmployees();
})

    }
  }



}
